﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // any
            // let number: number = 10;
            // let, ver, const

            //int number = 10;
            //double avg = 10.67;
            //decimal price = 99.99m;

            //// "", '', `${number}`
            ////string text = "TEXT";
            //string text2 = $"number: {number}";
            //char n = 'a';

            //bool isAdmin = true;

            Console.WriteLine("Hello");

            // Get user name
            Console.Write("Enter you name: ");
            string name = Console.ReadLine();
            Console.WriteLine($"Hello {name}");

            // Math Calculations
            Console.WriteLine("\n=== Math Calculator ===");

            Console.Write("Enter first number: ");
            double num1 = double.Parse(Console.ReadLine());

            Console.Write("Enter second number: ");
            double num2 = double.Parse(Console.ReadLine());

            // Perform calculations
            double addition = num1 + num2;
            double subtraction = num1 - num2;
            double multiplication = num1 * num2;
            double division = num2 != 0 ? num1 / num2 : 0;

            // Display results
            Console.WriteLine($"\n📊 Results:");
            Console.WriteLine($"Addition:       {num1} + {num2} = {addition}");
            Console.WriteLine($"Subtraction:    {num1} - {num2} = {subtraction}");
            Console.WriteLine($"Multiplication: {num1} × {num2} = {multiplication}");
            Console.WriteLine($"Division:       {num1} ÷ {num2} = {division}");

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
